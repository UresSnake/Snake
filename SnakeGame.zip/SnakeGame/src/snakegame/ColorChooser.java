/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Lenovo
 */
public class ColorChooser extends JPanel {

    private Main window;

    /**
     * You can choose color for two snakes by pressing the buttons of different colors
     * @param window
     */
    public ColorChooser(snakegame.Main window) {
        this.window = window;

        JLabel lab = new JLabel("Please choose a color!");

        JButton la = new JButton("First palyer");
        la.setBackground(Color.WHITE);
        JButton lb = new JButton("Second player");
        lb.setBackground(Color.WHITE);

        // Creating a new buttons
        JButton a = new JButton("BLUE");
        a.setBackground(Color.BLUE);
        a.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (la.getBackground().equals(Color.WHITE)) {
                    la.setBackground(Color.BLUE);
                } else {
                    lb.setBackground(Color.BLUE);
                }
                a.setEnabled(false);
            }
        });
        JButton b = new JButton("YELLOW");
        b.setBackground(Color.YELLOW);
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                b.setEnabled(false);
                if (la.getBackground().equals(Color.WHITE)) {
                    la.setBackground(Color.YELLOW);
                } else {
                    lb.setBackground(Color.YELLOW);
                }
                b.setEnabled(false);
            }
        });
        JButton c = new JButton("MAGENTA");
        c.setBackground(Color.MAGENTA);
        c.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (la.getBackground().equals(Color.WHITE)) {
                    la.setBackground(Color.MAGENTA);
                } else {
                    lb.setBackground(Color.MAGENTA);
                }
                c.setEnabled(false);
            }
        });
        JButton d = new JButton("CYAN");
        d.setBackground(Color.CYAN);
        d.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (la.getBackground().equals(Color.WHITE)) {
                    la.setBackground(Color.CYAN);
                } else {
                    lb.setBackground(Color.CYAN);
                }
                d.setEnabled(false);
            }
        });
        JButton ff = new JButton("Let's go!");
        ff.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Color a=la.getBackground();
                Color b=lb.getBackground();
                if (a.equals(b)) {
                JFrame parent = new JFrame("WARNING!");
                JOptionPane.showMessageDialog(parent, "You should choose color! ");

                window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_ACTIVATED));
                }
                else{
                Main f = new Main(a,b );
                }

            }
        });

        JButton back = new JButton("Back");
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Main f = new Main("1");

            }
        });

        setLayout(new BorderLayout(300, 200));
        setBorder(BorderFactory.createEtchedBorder());
        this.setBackground(Color.white);
        setForeground(Color.black);
        setFont(new Font("MsSanserif", Font.PLAIN, 10));
        Box box1 = Box.createHorizontalBox();
        box1.add(Box.createHorizontalGlue());
        box1.add(lab);
        box1.add(Box.createHorizontalGlue());

        Box box2 = Box.createHorizontalBox();
        box2.add(Box.createHorizontalGlue());
        box2.add(a);
        box2.add(Box.createHorizontalGlue());
        box2.add(b);
        box2.add(Box.createHorizontalGlue());
        box2.add(c);
        box2.add(Box.createHorizontalGlue());
        box2.add(d);
        box2.add(Box.createHorizontalGlue());

        Box box3 = Box.createHorizontalBox();
        box3.add(Box.createHorizontalGlue());
        box3.add(la);
        box3.add(Box.createHorizontalGlue());
        box3.add(lb);
        box3.add(Box.createHorizontalGlue());

        Box box4 = Box.createHorizontalBox();
        box4.add(Box.createHorizontalGlue());
        box4.add(ff);
        box4.add(Box.createHorizontalGlue());
        box4.add(back);
        box4.add(Box.createHorizontalGlue());

        Box boxx = Box.createVerticalBox();
        boxx.add(Box.createVerticalGlue());
        boxx.add(box1);
        boxx.add(Box.createVerticalGlue());
        boxx.add(box2);
        boxx.add(Box.createVerticalGlue());
        boxx.add(box3);
        boxx.add(Box.createVerticalGlue());
        boxx.add(box4);
        boxx.add(Box.createVerticalGlue());
        this.add(boxx, BorderLayout.CENTER);

    }
}
