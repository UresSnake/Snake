/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

/**
 *
 * @author Asus
 */
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

/**
 *
 * @author Lenovo
 */
public class Main extends JFrame implements KeyListener, ActionListener {

    Snakes snake;
    SettingsPanel settings;
    ColorChooser chooser;
    Color first;
    Color second;

    /**
     * Starting page for choosing one or two player
     * @param a
     */
    public Main(String a) {

        this.settings = new SettingsPanel(this);
        add(this.settings);

        setTitle("Settings");
        setSize(500, 500);
        this.addKeyListener(this);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * In case of two player you can choose the color of the snakes
     * @param a
     */
    public Main(int a) {

        this.chooser = new ColorChooser(this);
        add(this.chooser);

        setTitle("Color chooser");
        setSize(500, 500);
        this.addKeyListener(this);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * In case of two player the game begin
     * @param first
     * @param second
     */
    public Main(Color first, Color second) {
        // create the snake
        this.first = first;
        this.second = second;
        int winwidth=600;
         int winheight=600;
        
        this.snake = new Snakes(this, first, second,winwidth,winheight);

        // timer for redrawing the screen
        Timer timer = new Timer(600, this);
        timer.start();

        // timer for drawing apples on the screen
        java.util.Timer drawApples = new java.util.Timer();
        Apple st1 = new Apple(this.snake);

        drawApples.schedule(st1, 0, 500);

        java.util.Timer drawGoldApples = new java.util.Timer();
        GoldApple st2 = new GoldApple(this.snake);
        drawGoldApples.schedule(st2, 0, 3000);
        
        java.util.Timer drawRottenApples = new java.util.Timer();
        RottenApple st3 = new RottenApple(this.snake);
        drawRottenApples.schedule(st3, 0, 1000);

        // window creation & drawing
        add(this.snake);

        setTitle("Snake Game");
        setSize(winwidth, winheight);
        this.addKeyListener(this);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * In case of one player the game begin
     */
    public Main() {
        int winwidth=600;
         int winheight=600;
        this.snake = new Snakes(this, winwidth, winheight);

        // timer for redrawing the screen
        Timer timer = new Timer(300, this);
        timer.start();

        // timer for drawing apples on the screen
        java.util.Timer drawApples = new java.util.Timer();
        Apple st1 = new Apple(this.snake);

        drawApples.schedule(st1, 0, 500);

        java.util.Timer drawGoldApples = new java.util.Timer();
        GoldApple st2 = new GoldApple(this.snake);
        drawGoldApples.schedule(st2, 0, 3000);
        
        java.util.Timer drawRottenApples = new java.util.Timer();
        RottenApple st3 = new RottenApple(this.snake);
        drawRottenApples.schedule(st3, 0, 1000);

        // window creation & drawing
        add(this.snake);

        setTitle("Snake Game");
        setSize(winwidth, winheight);
        this.addKeyListener(this);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * When you type character input
     * @param e
     */
    @Override
    public void keyTyped(KeyEvent e) {
    }

    /**
     * When you release the key
     * @param e
     */
    @Override
    public void keyReleased(KeyEvent e) {
    }

    /**
     * The direction of the first(arrows) and second(WASD) snake when you press the key
     * @param e
     */
    @Override
    public void keyPressed(KeyEvent e) {

        int c = e.getKeyCode();

        if (c == 39 && !this.snake.getDirectiona().equals("left")) {
            this.snake.setDirectiona("right"); // right arrow pressed
        } else if (c == 37 && !this.snake.getDirectiona().equals("right")) {
            this.snake.setDirectiona("left"); // left arrow pressed
        } else if (c == 38 && !this.snake.getDirectiona().equals("down")) {
            this.snake.setDirectiona("up"); // up arrow pressed
        } else if (c == 40 && !this.snake.getDirectiona().equals("up")) {
            this.snake.setDirectiona("down"); // down arrow pressed
        } else if (c == 68 && !this.snake.getDirectionb().equals("left")) {
            this.snake.setDirectionb("right"); // right arrow pressed
        } else if (c == 65 && !this.snake.getDirectionb().equals("right")) {
            this.snake.setDirectionb("left"); // left arrow pressed
        } else if (c == 87 && !this.snake.getDirectionb().equals("down")) {
            this.snake.setDirectionb("up"); // up arrow pressed
        } else if (c == 83 && !this.snake.getDirectionb().equals("up")) {
            this.snake.setDirectionb("down"); // down arrow pressed
        }
    }

    /**
     * Redraw the panel
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        // redraw the screen
        repaint();
    }

    /**
     * Program starting point
     * @param args
     */
    public static void main(String[] args) {

        Main f = new Main("1");

        // EventQueue.invokeLater(Main::new);
    }

}
