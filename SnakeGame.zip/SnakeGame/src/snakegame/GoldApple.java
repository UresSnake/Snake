/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

import java.util.Random;
import java.util.TimerTask;

/**
 *
 * @author Asus
 */
public class GoldApple extends TimerTask{
    private int posx;
    private int posy;
    private Snakes snake;
    private int point=300;

    /**
     * Get the point value of the goldapple
     * @return
     */
    public int getPoint() {
        return point;
    }
 
    /**
     * Get the x position of the goldapple
     * @return
     */
    public int getPosx() {
        return posx;
    }

    /**
     * Get the y position of the goldapple
     * @return
     */
    public int getPosy() {
        return posy;
    }

    /**
     * Constructor of the gold apple
     * @param snake
     */
    public GoldApple(Snakes snake) {
        this.snake = snake;
    }

    /**
     * Create a new gold apple in a random position
     */
    public GoldApple() {
        this.posx = 25 * new Random().nextInt(21);
        this.posy = 25 * new Random().nextInt(21);
    }

    /**
     * If the snake ate a gold apple then create a new one after 1000 ms
     */
    @Override
    public void run() {
        if (this.snake.getGoldApple() == null) {
            this.snake.setGoldApple(new GoldApple());
        }
    }
    
}
