/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

/**
 *
 * @author Asus
 */
public class Rectangle {

    private int posx;
    private int posy;

    /**
     * Width of a part of the body of the snake
     */
    public static final int rec_width = 25;

    /**
     * Height of a part of the body of the snake
     */
    public static final int rec_height = 25;

    /**
     * The snake body part with x and y position
     * @param posx
     * @param posy
     */
    public Rectangle(int posx, int posy) {
        this.posx = posx;
        this.posy = posy;
    }

    /**
     * Check if intersection happened
     * @param r2
     * @return
     */
    public boolean intersects(Rectangle r2) {
        /*
        return true if x and y coordinates of
        this and r2 are the same
        */
        return this.posx == r2.getPosx() && this.posy == r2.getPosy();
    }

    /**
     * Get the x position
     * @return
     */
    public int getPosx() {
        return this.posx;
    }

    /**
     * Get the y position
     * @return
     */
    public int getPosy() {
        return this.posy;
    }

    /**
     * Set the x position
     * @param increment
     */
    public void setPosx(int increment) { this.posx = this.posx + increment; }

    /**
     * Set the y position
     * @param increment
     */
    public void setPosy(int increment) { this.posy =  this.posy + increment; }


}

