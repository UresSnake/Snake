/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package snakegame;

import java.util.Random;
import java.util.TimerTask;

/**
 *
 * @author Lenovo
 */
public class RottenApple extends TimerTask {

    private int posx;
    private int posy;
    private Snakes snake;

    private int point = 500;

    /**
     * Get the point value of the rottenapple
     * @return
     */
    public int getPoint() {
        return point;
    }

    /**
     * Get the x position of the rottenapple
     * @return
     */
    public int getPosx() {
        return posx;
    }

    /**
     * Get the y position of the rottenapple
     * @return
     */
    public int getPosy() {
        return posy;
    }

    /**
     * Constructor of the rotten apple
     * @param snake
     */
    public RottenApple(Snakes snake) {
        this.snake = snake;
    }

    /**
     * Create a new rotten apple in a random position
     */
    public RottenApple() {
        this.posx = 25 * new Random().nextInt(21);
        this.posy = 25 * new Random().nextInt(21);
    }

    /**
     * If the snake ate a rotten apple then create a new one after 1000 ms
     */
    @Override
    public void run() {
        if (this.snake.getRottenApple() == null) {
            this.snake.setRottenApple(new RottenApple());
        }
    }
}
