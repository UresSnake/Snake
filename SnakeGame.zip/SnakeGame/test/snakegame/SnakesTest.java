/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package snakegame;

import java.awt.Graphics;
import java.util.ArrayList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.equalTo;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Lenovo
 */
public class SnakesTest {

    public SnakesTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * The first snake is created
     */
    @Test
    public void testGetBody1() {
        System.out.println("getBody1");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        ArrayList<Rectangle> expResult = null;
        ArrayList<Rectangle> result = instance.getBody1();
        assertThat(expResult, not(result));

    }

    /**
     * The first snake is not equal with the second snake
     */
    @Test
    public void testGetBody2() {
        System.out.println("getBody2");
        Main a = new Main();
        Snakes instance = new Snakes(a, java.awt.Color.BLUE, java.awt.Color.MAGENTA, 500, 500);
        ArrayList<Rectangle> expResult = instance.getBody1();
        ArrayList<Rectangle> result = instance.getBody2();
        assertThat(expResult, not(result));
    }

    /**
     * The direction is set appropriately
     */
    @Test
    public void testSetDirectiona() {
        System.out.println("setDirectiona");
        String direction = "right";
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        instance.setDirectiona(direction);
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(instance.getDirectiona(), "right");
    }

    /**
     * Snake growing with a rectangle
     */   
    @Test
    public void testAddParta() {
        System.out.println("addParta");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        instance.addParta();
        // TODO review the generated test code and remove the default call to fail.
        assertThat(instance.getBody1().size(), is(4));
    }

    /**
     * Snake not colission with apple 
     */
    @Test
    public void testCheckColissiona() {
        System.out.println("checkColissiona");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        java.util.Timer drawApples = new java.util.Timer();
        Apple apple = new Apple(instance);
        drawApples.schedule(apple, 0, 300);

        int applex = apple.getPosx();
        int appley = apple.getPosy();
        Rectangle first = instance.getBody1().get(0);
        int headx = first.getPosx();
        int heady = first.getPosy();

        assertThat(applex & appley, is(not(equalTo(headx & heady))));
    }

    /**
     * Snake reach the right side of the court
     */
    @Test
    public void testCheckColissionaBorder() {
        System.out.println("checkColissionaBorder");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        for (int i = 250; i < 500; i = i + 25) {
            instance.setDirectiona("right");
            instance.moveSnakea();
        }

        int i = instance.getBody1().get(0).getPosx();
        assertThat(i, is(500));
    }

    /**
     * Snake moves to right and then down
     */
    @Test
    public void testMoveSnakea() {
        System.out.println("moveSnakea");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        Rectangle first = instance.getBody1().get(0);
        Rectangle head = new Rectangle(first.getPosx(), first.getPosy());
        int x = first.getPosx();
        int y = first.getPosy();

        instance.setDirectiona("right");
        instance.moveSnakea();

        Rectangle first2 = instance.getBody1().get(0);
        assertThat(x, is(not(equalTo(first2.getPosx()))));

        instance.setDirectiona("down");
        instance.moveSnakea();

        // TODO review the generated test code and remove the default call to fail.
        first2 = instance.getBody1().get(0);
        assertThat(y, is(not(equalTo(first2.getPosx()))));

    }

    /**
     * The apple newly created equals with the apple from the panel
     */
    @Test
    public void testSetApple() {
        System.out.println("setApple");
        Main a = new Main();
        Snakes instance = new Snakes(a, 500, 500);
        Apple apple = new Apple();
        instance.setApple(apple);
        assertEquals(instance.getApple(), apple);
    }

    
}
